# Импорт оценок из Edupage через неофициальную библиотеку edupage-api.
# Данные для входа берутся из тела запроса (форма на сайте) или из переменных окружения.
import json
import os
from http.server import BaseHTTPRequestHandler


def pack(g):
    d = getattr(g, "date", None)
    return {
        "eid": str(getattr(g, "event_id", "") or ""),
        "subject": getattr(g, "subject_name", None) or "",
        "v": getattr(g, "grade_n", None),
        "date": d.strftime("%Y-%m-%d") if hasattr(d, "strftime") else "",
        "note": getattr(g, "title", None) or getattr(g, "comment", None) or "",
    }


def run(headers, body):
    need = os.environ.get("APP_PASSWORD")
    if need and headers.get("x-pass") != need:
        return 401, {"error": "Неверный пароль приложения"}
    school = (body.get("school") or os.environ.get("EDUPAGE_SCHOOL") or "").strip()
    user = (body.get("user") or os.environ.get("EDUPAGE_USER") or "").strip()
    pw = body.get("pass") or os.environ.get("EDUPAGE_PASS") or ""
    if not (school and user and pw):
        return 400, {"error": "Нужны поддомен школы, логин и пароль"}
    try:
        from edupage_api import Edupage
        ep = Edupage()
        two_factor = ep.login(user, pw, school)
    except Exception as e:
        return 502, {"error": "Вход не удался (" + type(e).__name__ + "). Проверь логин, пароль и поддомен"}
    if two_factor is not None:
        return 502, {"error": "Для этого аккаунта включён двухфакторный вход, библиотека его не поддерживает"}
    try:
        grades = []
        for g in ep.get_grades():
            try:
                grades.append(pack(g))
            except Exception:
                pass
        return 200, {"grades": grades}
    except Exception as e:
        return 502, {"error": "Не удалось получить оценки (" + type(e).__name__ + ")"}


class handler(BaseHTTPRequestHandler):
    def do_POST(self):
        try:
            body = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}")
        except Exception:
            body = {}
        code, obj = run(self.headers, body)
        out = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(out)))
        self.end_headers()
        self.wfile.write(out)
